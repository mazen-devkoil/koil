<?php
// Heading 
$_['heading_title'] = 'Rev Slider Opencart';
$_['decimal_point']         = '.';
$_['thousand_point']        = ',';


?>