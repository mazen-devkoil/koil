<?php

// Heading Goes here:
$_['heading_title']    = '<b>Custom Module</b>';

// Text
$_['text_success']     = 'Success: You have modified module Custom Module!';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify module Custom Module!';

?>
