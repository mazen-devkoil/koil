<?php

// Heading Goes here:
$_['heading_title']    = '<b>Carousel item</b>';

// Text
$_['text_success']     = 'Success: You have modified module Carousel item!';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify module Carousel item!';

?>
