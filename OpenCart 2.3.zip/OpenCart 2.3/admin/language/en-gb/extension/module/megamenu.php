<?php

// Heading Goes here:
$_['heading_title']    = '<b>MegaMenu</b>';

// Text
$_['text_module']      = 'Modules';
$_['text_success']     = 'Success: You have modified module MegaMenu!';
$_['text_warning']     = 'Warning: Changes have not been saved! Make sure you have completed all fields well.';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify module MegaMenu!';

?>
