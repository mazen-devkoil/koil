<?php

// Heading Goes here:
$_['heading_title']    = '<b>Full screen background slider</b>';

// Text
$_['text_success']     = 'Success: You have modified module Full scren background slider!';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify module Full screen background slider!';

?>